package main

import (
	"strings"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/protos/peer"
)

type NettingScenario struct {
}

type CompanyDetails struct {
	companyName string
	totalAmount string
}

func main() {
	shim.Start(new(NettingScenario))
}

// Init is called during Instantiate transaction.
func (cc *NettingScenario) Init(stub shim.ChaincodeStubInterface) peer.Response {
	return initLedger(stub)
}

// Invoke is called to update or query the ledger in a proposal transaction.
func (cc *NettingScenario) Invoke(stub shim.ChaincodeStubInterface) peer.Response {

	function, args := stub.GetFunctionAndParameters()
	switch function {
	case "fetchTotalAmount":
		return fetchTotalAmount(stub, args)
	default:
		return shim.Error("Valid methods are 'initLedger|fetchTotalAmount'!")
	}
}

func initLedger(stub shim.ChaincodeStubInterface) peer.Response {
	companyDetails := []CompanyDetails{
		CompanyDetails{companyName: "A", totalAmount: "0"},
		CompanyDetails{companyName: "B", totalAmount: "0"},
		CompanyDetails{companyName: "C", totalAmount: "0"},
	}

	i := 0
	for i < len(companyDetails) {
		stub.PutState(companyDetails[i].companyName, []byte(companyDetails[i].totalAmount))
		i = i + 1
	}
	return shim.Success(nil)
}

// Read amount by companyName
func fetchTotalAmount(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) != 1 {
		return shim.Error("Parameter Mismatch")
	}

	companyName := strings.ToUpper(args[0])

	if value, err := stub.GetState(companyName); err == nil && value != nil {
		return shim.Success(value)
	}

	return shim.Error("Not Found")
}